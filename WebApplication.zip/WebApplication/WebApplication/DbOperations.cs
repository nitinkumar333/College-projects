﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;


namespace WebApplication
{
    public class DbOperations
    {
        private SqlConnection sqlconn;

        // Method for opening the connection to database.
        public string OpenConnection()
        {
            try
            {
                sqlconn = new SqlConnection();
                sqlconn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Admin\Documents\Collegedb1.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
                sqlconn.Open();
                return null;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        // Method for closing the connection
        private bool CloseConnection()
        {
            try
            {
                sqlconn.Close();
                return true;
            }
            catch { return false; }
        }

        // Code showing how to insert record to database.
        public bool Insert(string name, string email, string message)
        {
            try
            {
                string query = "INSERT INTO Feedback VALUES('" + name + "', '" + email + "', '" + message + "')";
                if (this.OpenConnection() == null)
                {
                    SqlCommand cmd = new SqlCommand(query, sqlconn);
                    int res = cmd.ExecuteNonQuery();
                    if (res >= 1)
                        return true;
                }
            }
            finally
            {
                this.CloseConnection();
            }
            return false;
        }
    }
}