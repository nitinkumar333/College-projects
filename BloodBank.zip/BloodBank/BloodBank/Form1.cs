﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace BloodBank
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewBloodGroup nbg = new NewBloodGroup();
            nbg.Show();
           /* this.Hide();*/
        }

       private void button2_Click(object sender, EventArgs e)
        {
            AddDonor ad = new AddDonor();
            ad.Show();
           /* this.Hide();*/
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Listof_Donors_BloodGroupwise ldb = new Listof_Donors_BloodGroupwise();
            ldb.Show();
           // this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ListofDonors_Genderwise ldg = new ListofDonors_Genderwise();
            ldg.Show();
          //  this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ListofDonors_Age_Weight_Gender lawg = new ListofDonors_Age_Weight_Gender();
            lawg.Show();
            this.Hide();
        }
    }
}
