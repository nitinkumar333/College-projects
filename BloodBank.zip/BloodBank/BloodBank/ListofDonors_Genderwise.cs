﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BloodBank
{
    public partial class ListofDonors_Genderwise : Form
    {
        SqlConnection con; 
        SqlDataAdapter da, da1; 
        DataSet ds, ds1;

        public ListofDonors_Genderwise()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            AddDonostoDGW();
        }
        public void AddDonostoDGW()
        {
            string sqlstr1 = "select * from tbl_Donors,tbl_BloodGroup where tbl_Donors.BloodID=tbl_BloodGroup.BloodID and	Gender='" + comboBox1.SelectedItem + "'";
            da1 = new SqlDataAdapter(sqlstr1, con); 
            ds1 = new DataSet();
            da1.Fill(ds1);
            dataGridView1.DataSource = ds1.Tables[0];
        }

        private void ListofDonors_Genderwise_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-D78R3BD;Initial Catalog=BLOODBANK;Integrated Security=True");
            con.Open();
            /* string sqlstr = "select distinct Gender from tbl_Donor"; 
             * da = new SqlDataAdapter(sqlstr, con);
               ds = new DataSet(); 
             * da.Fill(ds);
               cmb_SelectGender.DataSource = ds.Tables[0]; 
             * cmb_SelectGender.ValueMember = "Gender"; 
             * cmb_SelectGender.DisplayMember = "Gender"; */ 
            comboBox1.SelectedIndex = 0; 
            AddDonostoDGW();
        con.Close(); 

        }

    }
}
