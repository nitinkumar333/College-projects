﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BloodBank
{
    public partial class Listof_Donors_BloodGroupwise : Form
    {
        SqlConnection con; 
        SqlDataAdapter da, da1; 
        DataSet ds;
        DataSet ds1;

        public Listof_Donors_BloodGroupwise()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            AddDataGridviewcode();
        }

        private void Listof_Donors_BloodGroupwise_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-D78R3BD;Initial Catalog=BLOODBANK;Integrated Security=True");
            con.Open();
            string sqlstr = "select distinct BloodGroup from tbl_BloodGroup"; 
            da = new SqlDataAdapter(sqlstr, con);
            ds = new DataSet(); da.Fill(ds);
            comboBox1.DataSource = ds.Tables[0]; 
            comboBox1.ValueMember = "BloodGroup"; 
            comboBox1.DisplayMember = "BloodGroup";
            AddDataGridviewcode(); 
        con.Close();
        }
        public void AddDataGridviewcode()
        {

            string sqlstr1 = "select * from tbl_BloodGroup,tbl_Donors where tbl_BloodGroup.BloodID=tbl_Donors.BloodID and tbl_BloodGroup.BloodGroup='" + comboBox1.SelectedValue + "'";
            da1 = new SqlDataAdapter(sqlstr1, con); 
            ds1 = new DataSet();
            da1.Fill(ds1);
            dataGridView1.DataSource = ds1.Tables[0];

        }
       /* private void cmb_SelectBloodGroup_SelectionChangeCommitted(object sender, EventArgs e)
        {
            AddDataGridviewcode();
        }*/


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
