﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BloodBank
{
    public partial class NewBloodGroup : Form
    {
        SqlConnection con;
        SqlCommand cmd;

        public NewBloodGroup()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection ( "Data Source=DESKTOP-D78R3BD;Initial Catalog=BLOODBANK;Integrated Security=True");
            con.Open();
            string query = "insert into tbl_BloodGroup (BloodID,BloodGroup) values (" + textBox1.Text + ",'" + textBox2.Text + "')";
            cmd = new SqlCommand (query , con);
            cmd.CommandType = CommandType .Text;
            int j = cmd.ExecuteNonQuery();
            if (j > 0)
            {
                MessageBox .Show( "New Blood Group'" + textBox2.Text + "'Added Sucessfully" );
            }
            else
            {
                MessageBox .Show( "INSERTION FAILED" );
            }
        con.Close();
        }
    }
}
