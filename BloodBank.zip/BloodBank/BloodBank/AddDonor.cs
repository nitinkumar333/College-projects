﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BloodBank
{
    public partial class AddDonor : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        public AddDonor()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox5.Text = "";
            textBox4.Text = "";
            textBox3.Text = "";
            comboBox2.SelectedItem = "";
            comboBox1.SelectedItem = "";
        }

        private void AddDonor_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-D78R3BD;Initial Catalog=BLOODBANK;Integrated Security=True");
            con.Open();
            string sqlstr = "select BloodGroup from tbl_BloodGroup" ;
            da = new SqlDataAdapter (sqlstr, con);
            ds = new DataSet ();
            da.Fill(ds);
            comboBox2.DataSource = ds.Tables[0];
            comboBox2.ValueMember = "BloodGroup" ;
            comboBox1.SelectedIndex = 0;
        con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query1 = "select BloodID from tbl_BloodGroup where BloodGroup='" + comboBox2.SelectedValue + "' ";
            da = new SqlDataAdapter(query1, con); 
            DataTable dt = new DataTable(); 
            da.Fill(dt);
            int BloodID = int.Parse(dt.Rows[0][0].ToString());
            string query = "insert into tbl_Donors (DonorID,DonorName,Address,DOB,ContactNo,Gender,Weight,BloodID) values (" + textBox1.Text + ",'" + textBox2.Text + "','" + textBox3.Text + "','" + dateTimePicker1.Value + "'," + textBox4.Text + ",'" + comboBox1.SelectedItem + "'," + textBox5.Text + "," + BloodID + ")";
            cmd = new SqlCommand(query , con);
            int j = cmd.ExecuteNonQuery();
            if (j > 0)
            {
                MessageBox.Show("New Donor'" + textBox2.Text + "' Added Sucessfully");
            }
            else
            {
                MessageBox.Show("INSERTION FAILED");
            }
        con.Close();

        }
    }
}
