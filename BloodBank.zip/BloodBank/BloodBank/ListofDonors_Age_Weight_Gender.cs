﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BloodBank
{
    public partial class ListofDonors_Age_Weight_Gender : Form
    {
        SqlConnection con; 
        SqlDataAdapter da1;
        DataSet ds1;

        public ListofDonors_Age_Weight_Gender()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            AddDonorsDGW();
        }
        public void AddDonorsDGW()
        {
            con.Open();
            string sqlstr = "select * from tbl_Donors,tbl_BloodGroup where tbl_BloodGroup.BloodID=tbl_Donors.BloodID  AND Weight>45 AND Gender='" + comboBox1.SelectedItem + "'";
            da1 = new SqlDataAdapter(sqlstr, con); 
            ds1 = new DataSet();
            da1.Fill(ds1);
            dataGridView1.DataSource = ds1.Tables[0]; 
         con.Close();
        }

        private void ListofDonors_Age_Weight_Gender_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-D78R3BD;Initial Catalog=BLOODBANK;Integrated Security=True");
            comboBox1.SelectedIndex = 0;
            AddDonorsDGW();

        }
    }
}
