﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Studentlab
{
    public partial class DisplayStudentsYearwise : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da, da1;
        DataSet ds;
        DataSet ds1;

        public DisplayStudentsYearwise()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
        public void adddata()
        {

            string sqlstr1 = "select * from tbl_Student where YrOfAdmsn=" + comboBox1.SelectedValue + "";
            /*string sqlstr1 = "select * from tbl_Student"; */
            da1 = new SqlDataAdapter(sqlstr1, con);
            ds1 = new DataSet();
            da1.Fill(ds1);
            dataGridView2.DataSource = ds1.Tables[0];
           
        }

        private void DisplayStudentsYearwise_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-D78R3BD;Initial Catalog=STUDENT;Integrated Security=True");
            con.Open();
            string sqlstr = "select YrOfAdmsn from tbl_Student";
            da = new SqlDataAdapter(sqlstr, con);
            ds = new DataSet();
            da.Fill(ds);
            comboBox1.DataSource = ds.Tables[0];
            comboBox1.ValueMember = "YrOfAdmsn";
            comboBox1.DisplayMember = "YrOfAdmsn";
            adddata();
            con.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            adddata();
        }
    }
}
