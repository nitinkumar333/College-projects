﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Studentlab
{
    public partial class NewStudent : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        public NewStudent()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = " select CourseID from tbl_Course where CourseName='"+ comboBox1.SelectedValue + "' " ;
            da = new SqlDataAdapter (query, con);
            DataTable dt = new DataTable ();
            da.Fill(dt);
            int CourseID = int .Parse(dt.Rows[0][0].ToString());
            cmd = new SqlCommand ( "insert into tbl_Student(USN,StudName,Address,CourseID,YrOfAdmsn) values ('" + textBox1.Text + "','"+ textBox2.Text+"','" +textBox3.Text+ "'," +CourseID+ "," + comboBox2.SelectedItem+ ")" , con);
            cmd.CommandType = CommandType .Text;
            int j = cmd.ExecuteNonQuery();
            if (j > 0)
            {
                MessageBox .Show( "New Student'" + textBox2.Text + "' Added Sucessfully" );
            }
            else
            {
                MessageBox .Show( "INSERTION FAILED" );
            }
            con.Close();
        }

        private void NewStudent_Load_1(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-D78R3BD;Initial Catalog=STUDENT;Integrated Security=True");
            con.Open();
            string sqlstr = "select CourseName from tbl_Course";
            da = new SqlDataAdapter(sqlstr, con);
            ds = new DataSet();
            da.Fill(ds);
            comboBox1.DataSource = ds.Tables[0];
            comboBox1.ValueMember = "CourseName";
            con.Close();
        }
    }
}
