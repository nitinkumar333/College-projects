﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Studentlab
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewCourse ns = new NewCourse();
            ns.Show();
          //  this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NewStudent ns1 = new NewStudent();
            ns1.Show();
           // this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DisplayingStudentsCoursewise dsc = new DisplayingStudentsCoursewise();
            dsc.Show();
          //  this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DisplayStudentsYearwise dsy = new DisplayStudentsYearwise();
            dsy.Show();
           // this.Hide();
        }
    }
}
