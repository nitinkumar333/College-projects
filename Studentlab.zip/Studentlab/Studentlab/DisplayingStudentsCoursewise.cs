﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Studentlab
{
    public partial class DisplayingStudentsCoursewise : Form
    {
        SqlConnection con;
        SqlDataAdapter da, da1;
        DataSet ds;
        DataSet ds1;

        public DisplayingStudentsCoursewise()
        {
            InitializeComponent();
        }
        

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            loaddata();
        }
        public void loaddata()
        {
            string sqlstr1 = "select * from tbl_Student,tbl_Course where tbl_Course.CourseID=tbl_Student.CourseID and tbl_Course.CourseName='" +comboBox1.SelectedValue + "'" ;
            da1 = new SqlDataAdapter (sqlstr1, con);
            ds1 = new DataSet ();
            da1.Fill(ds1);
            dataGridView1.DataSource = ds1.Tables[0];
        }

        private void DisplayingStudentsCoursewise_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-D78R3BD;Initial Catalog=STUDENT;Integrated Security=True");
            con.Open();
            string sqlstr = "select CourseName from tbl_Course";
            da = new SqlDataAdapter(sqlstr, con);
            ds = new DataSet();
            da.Fill(ds);
            comboBox1.DataSource = ds.Tables[0];
            comboBox1.ValueMember = "CourseName";
            comboBox1.DisplayMember = "CourseName";
            loaddata();
            con.Close();
        }
    }
}
