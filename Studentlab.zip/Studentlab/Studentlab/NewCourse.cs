﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Studentlab
{
    public partial class NewCourse : Form
    {
        SqlConnection con;
        SqlCommand cmd;

        public NewCourse()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-D78R3BD;Initial Catalog=STUDENT;Integrated Security=True");
            con.Open();
            cmd = new SqlCommand("insert into tbl_Course (CourseID,CourseName) values (" + textBox1.Text + ",'" + textBox2.Text + "')", con);
            cmd.CommandType = CommandType.Text;
            int j = cmd.ExecuteNonQuery();
            if(j>0)
            {
                MessageBox.Show("New Course'" +textBox2.Text+"' Added Successfully");
            }
            else
            {
                MessageBox.Show("INSERTION FAILED");
            }
            con.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
